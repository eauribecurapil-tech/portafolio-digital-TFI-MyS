"""
TFI Modelos y Simulación - Adopción de Rust vs C++
Etapa 4: Formulación del modelo Bass e implementación de la simulación

Modelo: difusión de Bass (variante del SIR)
    dN/dt = (p + q·N/m) · (m - N)
donde:
    N(t) = fracción acumulada de adoptantes
    p    = coeficiente de innovación (influencia externa)
    q    = coeficiente de imitación (boca a boca)
    m    = mercado potencial (techo de adopción)

Este script:
1. Carga los datos limpios de la etapa 3
2. Ajusta los parámetros (p, q, m) contra los datos reales
3. Valida el modelo con train/test split (2016-2022 / 2023-2025)
4. Corre 3 escenarios contrafácticos
5. Proyecta hasta 2030
6. Genera figuras publicables y un CSV de resultados
"""

import os
import numpy as np
import pandas as pd
from scipy.integrate import odeint
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import json

# ============================================================
# Estilo de matplotlib
# ============================================================
plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['DejaVu Sans', 'Arial'],
    'font.size': 11,
    'axes.titlesize': 13,
    'axes.titleweight': 'bold',
    'axes.labelsize': 11,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.grid': True,
    'grid.alpha': 0.25,
    'grid.linestyle': '--',
    'legend.frameon': False,
    'figure.dpi': 120,
    'savefig.dpi': 150,
    'savefig.bbox': 'tight',
})

# Paleta de colores consistente con el resto del proyecto
COL_RUST = '#D85A30'
COL_RUST_DARK = '#8B2E0F'
COL_CPP = '#378ADD'
COL_CPP_DARK = '#1F4A7A'
COL_GRAY = '#888780'
COL_GREEN = '#1D9E75'
COL_AMBER = '#BA7517'

BASE_DIR = r'C:\Users\neoss\Desktop\Proyectos\UNNOBA\Materias\Cuarto año\Primer Cuatrimestre\Modelos y Simulación\Trabajo Integrador Final\Código'
FIG_DIR = f'{BASE_DIR}/simulacion/figuras'
RES_DIR = f'{BASE_DIR}/simulacion/resultados'

# Crear las carpetas si no existen
os.makedirs(FIG_DIR, exist_ok=True)
os.makedirs(RES_DIR, exist_ok=True)

# ============================================================
# 1. Carga de datos
# ============================================================
df = pd.read_csv(f'{BASE_DIR}/datos_para_simulacion.csv')
print("Datos cargados:")
print(df.to_string(index=False))
print()

t_data = df['t'].values.astype(float)           # años desde 2016
N_data = df['rust_pct'].values / 100.0          # fracción adoptantes Rust
C_data = df['cpp_pct'].values / 100.0           # fracción C++
years = df['year'].values

# ============================================================
# 2. Modelo Bass (forma analítica) + ajuste
# ============================================================
def bass_analytical(t, p, q, m):
    """
    Solución analítica del modelo Bass:
        N(t) = m * (1 - exp(-(p+q)*t)) / (1 + (q/p)*exp(-(p+q)*t))
    """
    expterm = np.exp(-(p + q) * t)
    F = (1.0 - expterm) / (1.0 + (q / p) * expterm)
    return m * F

# Estimaciones iniciales razonables para tecnología de adopción media
p0 = [0.003, 0.4, 0.30]
bounds = ([1e-5, 0.05, 0.10], [0.2, 2.5, 1.0])

popt, pcov = curve_fit(bass_analytical, t_data, N_data,
                        p0=p0, bounds=bounds, maxfev=10000)
p_fit, q_fit, m_fit = popt
perr = np.sqrt(np.diag(pcov))  # errores estándar

print(f"\n=== AJUSTE MODELO BASS (con todos los datos 2016-2025) ===")
print(f"p (innovación)        = {p_fit:.5f}  ± {perr[0]:.5f}")
print(f"q (imitación)         = {q_fit:.4f}  ± {perr[1]:.4f}")
print(f"m (mercado potencial) = {m_fit*100:.2f}% ± {perr[2]*100:.2f}%")

# Residuos y R²
N_pred = bass_analytical(t_data, p_fit, q_fit, m_fit)
ss_res = np.sum((N_data - N_pred) ** 2)
ss_tot = np.sum((N_data - np.mean(N_data)) ** 2)
r2 = 1 - ss_res / ss_tot
rmse = np.sqrt(np.mean((N_data - N_pred) ** 2)) * 100  # en pp
print(f"R² del ajuste         = {r2:.4f}")
print(f"RMSE                  = {rmse:.3f} pp")

# ============================================================
# 3. Validación: ajustar con 2016-2022, predecir 2023-2025
# ============================================================
train_mask = t_data <= 6  # años 2016-2022
test_mask = t_data > 6    # años 2023-2025

popt_train, _ = curve_fit(bass_analytical,
                          t_data[train_mask], N_data[train_mask],
                          p0=p0, bounds=bounds, maxfev=10000)
p_tr, q_tr, m_tr = popt_train

N_pred_train = bass_analytical(t_data[train_mask], *popt_train)
N_pred_test = bass_analytical(t_data[test_mask], *popt_train)
N_real_test = N_data[test_mask]

rmse_test = np.sqrt(np.mean((N_real_test - N_pred_test) ** 2)) * 100

print(f"\n=== VALIDACIÓN: ajuste con 2016-2022, predicción 2023-2025 ===")
print(f"Parámetros con train: p={p_tr:.5f}, q={q_tr:.4f}, m={m_tr*100:.2f}%")
print(f"Predicción 2023: {N_pred_test[0]*100:.2f}% (real: {N_real_test[0]*100:.2f}%)")
print(f"Predicción 2024: {N_pred_test[1]*100:.2f}% (real: {N_real_test[1]*100:.2f}%)")
print(f"Predicción 2025: {N_pred_test[2]*100:.2f}% (real: {N_real_test[2]*100:.2f}%)")
print(f"RMSE en test         = {rmse_test:.3f} pp")

# ============================================================
# 4. Modelo Bass numérico (para escenarios con parámetros variables)
# ============================================================
def bass_ode(N, t, p_func, q, m):
    """ODE del modelo Bass: permite que p sea función del tiempo."""
    p = p_func(t)
    return (p + q * N / m) * (m - N)

def simulate_bass(t_eval, p_func, q, m, N0=None):
    """Integra el modelo Bass numéricamente."""
    if N0 is None:
        # Condición inicial: N(0) del ajuste analítico
        N0 = bass_analytical(np.array([0.001]), p_fit, q_fit, m_fit)[0]
    sol = odeint(bass_ode, N0, t_eval, args=(p_func, q, m))
    return sol.flatten()

# ============================================================
# 5. Escenarios contrafácticos (proyectados hasta 2030)
# ============================================================
t_proj = np.linspace(0, 14, 281)  # 2016 a 2030, paso ~mensual
years_proj = 2016 + t_proj

# Escenario 1: BASE (sin shocks, parámetros ajustados)
N_base = bass_analytical(t_proj, p_fit, q_fit, m_fit)

# Escenario 2: SHOCK REGULATORIO (CRA EU + White House)
# A partir de t=8 (2024), p se duplica por el efecto de la regulación
def p_shock(t):
    return p_fit if t < 8 else p_fit * 2.0

N_shock = simulate_bass(t_proj, p_shock, q_fit, m_fit)

# Escenario 3: CONSERVADOR (mercado potencial menor: m * 0.7)
N_conserv = bass_analytical(t_proj, p_fit, q_fit, m_fit * 0.7)

# Escenario 4: VARIANTE SIR CON ABANDONO
# Algunos usuarios prueban Rust y vuelven a C++ (tasa α)
def bass_con_abandono(state, t, p, q, m, alpha):
    N, A = state  # N = adoptantes acumulados, A = abandonadores
    activos = N - A
    dN = (p + q * activos / m) * (m - N)
    dA = alpha * activos
    return [dN, dA]

alpha = 0.05  # 5% anual de abandono
N0_init = bass_analytical(np.array([0.001]), p_fit, q_fit, m_fit)[0]
sol_aband = odeint(bass_con_abandono, [N0_init, 0], t_proj,
                    args=(p_fit, q_fit, m_fit, alpha))
N_aband_total = sol_aband[:, 0]
A_aband = sol_aband[:, 1]
N_aband_activos = N_aband_total - A_aband

# ============================================================
# 6. Modelo simple para C++ (declive logístico decreciente)
# ============================================================
# Ajustamos una curva exponencial decreciente para C++:
# C(t) = C_inf + (C_0 - C_inf) * exp(-k*t)
def cpp_decay(t, c_inf, c_0, k):
    return c_inf + (c_0 - c_inf) * np.exp(-k * t)

# Solo usamos los últimos años donde el declive es visible (2020-2025)
recent_mask = t_data >= 4
popt_cpp, _ = curve_fit(cpp_decay, t_data[recent_mask], C_data[recent_mask],
                         p0=[0.10, 0.24, 0.1], bounds=([0.05, 0.15, 0.01], [0.20, 0.30, 1.0]))
C_proj = cpp_decay(t_proj, *popt_cpp)
print(f"\nAjuste C++ (declive): C_∞={popt_cpp[0]*100:.1f}%, C_0={popt_cpp[1]*100:.1f}%, k={popt_cpp[2]:.3f}")

# Punto de cruce: ¿cuándo Rust > C++ en cada escenario?
def find_crossover(t_arr, N_arr, C_arr):
    diff = N_arr - C_arr
    crossings = np.where(np.diff(np.sign(diff)))[0]
    if len(crossings) > 0:
        idx = crossings[0]
        # Interpolación lineal
        frac = -diff[idx] / (diff[idx+1] - diff[idx])
        return t_arr[idx] + frac * (t_arr[idx+1] - t_arr[idx])
    return None

t_cross_base = find_crossover(t_proj, N_base, C_proj)
t_cross_shock = find_crossover(t_proj, N_shock, C_proj)

print(f"\n=== CRUCE Rust > C++ ===")
print(f"Escenario base:   {2016 + t_cross_base:.2f}" if t_cross_base else "  base: no cruza antes de 2030")
print(f"Escenario shock:  {2016 + t_cross_shock:.2f}" if t_cross_shock else "  shock: no cruza antes de 2030")

# ============================================================
# 7. FIGURAS
# ============================================================

# --- Figura 1: Ajuste del modelo Bass contra datos reales ---
fig, ax = plt.subplots(figsize=(10, 6))
t_smooth = np.linspace(0, 9.5, 200)
N_smooth = bass_analytical(t_smooth, p_fit, q_fit, m_fit)
ax.plot(2016 + t_smooth, N_smooth * 100, color=COL_RUST, lw=2.5, label=f'Bass ajustado (R²={r2:.3f})')
ax.scatter(2016 + t_data, N_data * 100, color=COL_RUST_DARK, s=80, zorder=5,
            label='Datos reales (Stack Overflow)', edgecolors='white', linewidths=1.5)
ax.set_xlabel('Año')
ax.set_ylabel('% de desarrolladores usando Rust')
ax.set_title('Modelo Bass ajustado a la adopción de Rust (2016-2025)')
ax.legend(loc='upper left')

# Anotación con parámetros
textstr = f'$p$ = {p_fit:.4f}\n$q$ = {q_fit:.3f}\n$m$ = {m_fit*100:.1f}%'
ax.text(0.97, 0.03, textstr, transform=ax.transAxes, fontsize=11,
        verticalalignment='bottom', horizontalalignment='right',
        bbox=dict(boxstyle='round,pad=0.6', facecolor='white',
                  edgecolor=COL_GRAY, linewidth=0.5))

ax.set_xlim(2015.5, 2026)
ax.set_ylim(0, 16)
plt.tight_layout()
plt.savefig(f'{FIG_DIR}/fig1_ajuste_bass.png')
plt.close()
print(f"\nFigura 1 generada: ajuste Bass")

# --- Figura 2: Validación train/test ---
fig, ax = plt.subplots(figsize=(10, 6))
t_smooth2 = np.linspace(0, 9.5, 200)
N_smooth_tr = bass_analytical(t_smooth2, *popt_train)
ax.plot(2016 + t_smooth2, N_smooth_tr * 100, color=COL_RUST, lw=2.5,
        label='Modelo ajustado con 2016-2022')
ax.scatter(2016 + t_data[train_mask], N_data[train_mask] * 100, color=COL_RUST_DARK,
            s=80, zorder=5, label='Datos train (2016-2022)', edgecolors='white', linewidths=1.5)
ax.scatter(2016 + t_data[test_mask], N_data[test_mask] * 100, color=COL_GREEN,
            s=110, marker='D', zorder=5, label='Datos test (2023-2025)',
            edgecolors='white', linewidths=1.5)
ax.axvline(2022.5, color=COL_GRAY, ls=':', alpha=0.6, label='División train/test')

# Línea de predicción
ax.plot(2016 + t_data[test_mask], N_pred_test * 100, color=COL_GREEN,
        ls='--', lw=2, label=f'Predicción (RMSE = {rmse_test:.2f} pp)')

ax.set_xlabel('Año')
ax.set_ylabel('% de desarrolladores usando Rust')
ax.set_title('Validación del modelo: predicción out-of-sample 2023-2025')
ax.legend(loc='upper left')
ax.set_xlim(2015.5, 2026)
ax.set_ylim(0, 16)
plt.tight_layout()
plt.savefig(f'{FIG_DIR}/fig2_validacion.png')
plt.close()
print("Figura 2 generada: validación train/test")

# --- Figura 3: Escenarios proyectados hasta 2030 ---
fig, ax = plt.subplots(figsize=(11, 6.5))
ax.plot(years_proj, N_base * 100, color=COL_RUST, lw=2.5, label='Escenario base (sin shocks)')
ax.plot(years_proj, N_shock * 100, color=COL_AMBER, lw=2.5, ls='--',
        label='Escenario shock regulatorio (p×2 desde 2024)')
ax.plot(years_proj, N_conserv * 100, color=COL_GRAY, lw=2, ls=':',
        label='Escenario conservador (m = 70% del base)')
ax.plot(years_proj, N_aband_activos * 100, color=COL_GREEN, lw=2, ls='-.',
        label=f'SIR con abandono (α = {alpha})')

# Datos reales superpuestos
ax.scatter(2016 + t_data, N_data * 100, color=COL_RUST_DARK, s=70, zorder=5,
            label='Datos reales SO', edgecolors='white', linewidths=1.5)

# Eventos exógenos
ax.axvline(2022, color=COL_GRAY, ls=':', alpha=0.4)
ax.text(2022, 35, 'Linux 6.1\nacepta Rust', fontsize=9, ha='center',
        color=COL_GRAY, alpha=0.9)
ax.axvline(2024.15, color=COL_GRAY, ls=':', alpha=0.4)
ax.text(2024.15, 35, 'White House:\nmemory-safe', fontsize=9, ha='center',
        color=COL_GRAY, alpha=0.9)
ax.axvline(2026.25, color=COL_GRAY, ls=':', alpha=0.4)
ax.text(2026.25, 35, 'CRA EU\nentra en vigor', fontsize=9, ha='center',
        color=COL_GRAY, alpha=0.9)

ax.set_xlabel('Año')
ax.set_ylabel('% de desarrolladores usando Rust')
ax.set_title('Escenarios contrafácticos: proyección de adopción de Rust hasta 2030')
ax.legend(loc='upper left', fontsize=10)
ax.set_xlim(2016, 2030)
ax.set_ylim(0, 40)
plt.tight_layout()
plt.savefig(f'{FIG_DIR}/fig3_escenarios.png')
plt.close()
print("Figura 3 generada: escenarios contrafácticos")

# --- Figura 4: Rust vs C++ con punto de cruce ---
fig, ax = plt.subplots(figsize=(11, 6.5))
ax.plot(years_proj, N_base * 100, color=COL_RUST, lw=2.5, label='Rust (modelo Bass base)')
ax.plot(years_proj, N_shock * 100, color=COL_RUST, lw=2, ls='--', alpha=0.7,
        label='Rust (escenario shock)')
ax.plot(years_proj, C_proj * 100, color=COL_CPP, lw=2.5, label='C++ (declive exponencial)')

# Datos reales
ax.scatter(2016 + t_data, N_data * 100, color=COL_RUST_DARK, s=70, zorder=5,
            edgecolors='white', linewidths=1.5)
ax.scatter(2016 + t_data, C_data * 100, color=COL_CPP_DARK, s=70, zorder=5,
            edgecolors='white', linewidths=1.5)

# Marcar el punto de cruce
if t_cross_base:
    y_cross = bass_analytical(np.array([t_cross_base]), p_fit, q_fit, m_fit)[0] * 100
    ax.scatter([2016 + t_cross_base], [y_cross], color=COL_GREEN, s=200, zorder=10,
                marker='*', edgecolors='white', linewidths=2,
                label=f'Cruce base: {2016 + t_cross_base:.1f}')
if t_cross_shock and t_cross_shock != t_cross_base:
    y_cross_s = simulate_bass(np.array([t_cross_shock]), p_shock, q_fit, m_fit)[0] * 100
    ax.scatter([2016 + t_cross_shock], [y_cross_s], color=COL_AMBER, s=200, zorder=10,
                marker='*', edgecolors='white', linewidths=2,
                label=f'Cruce shock: {2016 + t_cross_shock:.1f}')

ax.set_xlabel('Año')
ax.set_ylabel('% de desarrolladores')
ax.set_title('Rust vs C++: pregunta de investigación principal')
ax.legend(loc='center left', fontsize=10)
ax.set_xlim(2016, 2030)
ax.set_ylim(0, 30)
plt.tight_layout()
plt.savefig(f'{FIG_DIR}/fig4_cruce_rust_cpp.png')
plt.close()
print("Figura 4 generada: cruce Rust vs C++")

# --- Figura 5: Análisis de sensibilidad p, q ---
fig, axes = plt.subplots(1, 2, figsize=(13, 5.5))

# Sensibilidad en p
ax = axes[0]
for factor, ls in zip([0.5, 0.75, 1.0, 1.5, 2.0], ['-', '--', '-', '--', '-']):
    N_s = bass_analytical(t_proj, p_fit * factor, q_fit, m_fit)
    alpha_line = 1.0 if factor == 1.0 else 0.5
    lw = 2.8 if factor == 1.0 else 1.5
    label = f'p × {factor}' + (' (base)' if factor == 1.0 else '')
    ax.plot(years_proj, N_s * 100, color=COL_RUST, alpha=alpha_line, lw=lw,
            ls=ls, label=label)
ax.set_xlabel('Año'); ax.set_ylabel('% adoptantes Rust')
ax.set_title('Sensibilidad: coeficiente de innovación (p)')
ax.legend(fontsize=9); ax.set_xlim(2016, 2030); ax.set_ylim(0, 35)

# Sensibilidad en q
ax = axes[1]
for factor, ls in zip([0.5, 0.75, 1.0, 1.5, 2.0], ['-', '--', '-', '--', '-']):
    N_s = bass_analytical(t_proj, p_fit, q_fit * factor, m_fit)
    alpha_line = 1.0 if factor == 1.0 else 0.5
    lw = 2.8 if factor == 1.0 else 1.5
    label = f'q × {factor}' + (' (base)' if factor == 1.0 else '')
    ax.plot(years_proj, N_s * 100, color=COL_CPP, alpha=alpha_line, lw=lw,
            ls=ls, label=label)
ax.set_xlabel('Año'); ax.set_ylabel('% adoptantes Rust')
ax.set_title('Sensibilidad: coeficiente de imitación (q)')
ax.legend(fontsize=9); ax.set_xlim(2016, 2030); ax.set_ylim(0, 35)

plt.tight_layout()
plt.savefig(f'{FIG_DIR}/fig5_sensibilidad.png')
plt.close()
print("Figura 5 generada: análisis de sensibilidad")

# --- Figura 6: Velocidad de adopción dN/dt ---
fig, ax = plt.subplots(figsize=(10, 6))
dN_dt = np.gradient(N_base, t_proj) * 100  # pp por año
ax.fill_between(years_proj, dN_dt, color=COL_RUST, alpha=0.25)
ax.plot(years_proj, dN_dt, color=COL_RUST, lw=2.5, label='dN/dt (pp por año)')

# Marcar el pico de adopción
idx_peak = np.argmax(dN_dt)
ax.scatter([years_proj[idx_peak]], [dN_dt[idx_peak]], color=COL_RUST_DARK, s=150,
            zorder=10, marker='v', edgecolors='white', linewidths=1.5,
            label=f'Pico de adopción: {years_proj[idx_peak]:.1f}')
ax.axvline(years_proj[idx_peak], color=COL_RUST_DARK, ls=':', alpha=0.5)

ax.set_xlabel('Año')
ax.set_ylabel('Velocidad de adopción (puntos porcentuales por año)')
ax.set_title('Velocidad de adopción de Rust: ¿cuándo es el pico?')
ax.legend(loc='upper right')
ax.set_xlim(2016, 2030)
ax.set_ylim(0, max(dN_dt) * 1.15)
plt.tight_layout()
plt.savefig(f'{FIG_DIR}/fig6_velocidad_adopcion.png')
plt.close()
print(f"Figura 6 generada: velocidad de adopción (pico en {years_proj[idx_peak]:.2f})")

# ============================================================
# 8. CSV con resultados de las proyecciones
# ============================================================
df_proj = pd.DataFrame({
    'año': np.round(years_proj, 3),
    'rust_base_pct': np.round(N_base * 100, 3),
    'rust_shock_pct': np.round(N_shock * 100, 3),
    'rust_conserv_pct': np.round(N_conserv * 100, 3),
    'rust_aband_activos_pct': np.round(N_aband_activos * 100, 3),
    'cpp_proj_pct': np.round(C_proj * 100, 3),
})
df_proj.to_csv(f'{RES_DIR}/proyecciones_2016_2030.csv', index=False)
print(f"\nCSV de proyecciones guardado en {RES_DIR}/proyecciones_2016_2030.csv")

# JSON con parámetros y métricas clave para usar en el web y el documento
resumen = {
    'parametros_ajustados': {
        'p_innovacion': round(p_fit, 5),
        'q_imitacion': round(q_fit, 4),
        'm_mercado_potencial_pct': round(m_fit * 100, 2),
        'p_error_std': round(perr[0], 5),
        'q_error_std': round(perr[1], 4),
        'm_error_std_pct': round(perr[2] * 100, 2),
    },
    'bondad_ajuste': {
        'R_cuadrado': round(r2, 4),
        'RMSE_pp': round(rmse, 3),
    },
    'validacion_train_test': {
        'rango_train': '2016-2022',
        'rango_test': '2023-2025',
        'rmse_test_pp': round(rmse_test, 3),
        'predicciones_test': {
            int(years[6+i]): {
                'real_pct': round(N_real_test[i] * 100, 2),
                'predicho_pct': round(N_pred_test[i] * 100, 2),
            } for i in range(len(N_real_test))
        },
    },
    'punto_de_cruce_rust_supera_cpp': {
        'escenario_base': round(2016 + t_cross_base, 2) if t_cross_base else None,
        'escenario_shock': round(2016 + t_cross_shock, 2) if t_cross_shock else None,
    },
    'pico_velocidad_adopcion': {
        'año': round(years_proj[idx_peak], 2),
        'velocidad_pp_por_año': round(dN_dt[idx_peak], 3),
    },
    'proyeccion_2030': {
        'base_pct': round(N_base[-1] * 100, 2),
        'shock_pct': round(N_shock[-1] * 100, 2),
        'conservador_pct': round(N_conserv[-1] * 100, 2),
        'cpp_pct': round(C_proj[-1] * 100, 2),
    },
}

with open(f'{RES_DIR}/resumen_simulacion.json', 'w') as f:
    json.dump(resumen, f, indent=2, ensure_ascii=False)
print(f"Resumen JSON guardado en {RES_DIR}/resumen_simulacion.json")

# Resumen ejecutivo en stdout
print("\n" + "="*60)
print("RESUMEN EJECUTIVO DE LA SIMULACIÓN")
print("="*60)
print(f"Modelo: Bass de difusión (variante SIR)")
print(f"Ajuste: p={p_fit:.4f}, q={q_fit:.3f}, m={m_fit*100:.1f}%")
print(f"R² = {r2:.3f}, RMSE = {rmse:.2f} pp")
print(f"Validación 2023-25: RMSE = {rmse_test:.2f} pp")
print(f"")
print(f"PROYECCIÓN 2030:")
print(f"  Base:        {N_base[-1]*100:.1f}% de devs usan Rust")
print(f"  Shock CRA:   {N_shock[-1]*100:.1f}%")
print(f"  Conservador: {N_conserv[-1]*100:.1f}%")
print(f"  C++ proj:    {C_proj[-1]*100:.1f}%")
print(f"")
print(f"PICO DE VELOCIDAD: {years_proj[idx_peak]:.1f} ({dN_dt[idx_peak]:.2f} pp/año)")
if t_cross_base:
    print(f"CRUCE Rust > C++ (base):  {2016 + t_cross_base:.1f}")
if t_cross_shock:
    print(f"CRUCE Rust > C++ (shock): {2016 + t_cross_shock:.1f}")
print("="*60)
