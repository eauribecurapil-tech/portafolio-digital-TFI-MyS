# Recolección y limpieza de datos — Etapas 2 y 3 del TFI

**Trabajo Final Integrador — Modelos y Simulación**
**Tema:** Adopción de Rust como reemplazo de C++ en programación de sistemas
**Modelo:** Bass / SIR de difusión

---

## 1. Fuentes utilizadas

Se eligieron cuatro fuentes públicas que se complementan: una primaria (encuesta a desarrolladores), una secundaria de validación (índice por volumen de búsqueda), una para interés social (tendencia de búsqueda) y reportes de prensa especializada para contextualizar eventos relevantes.

### 1.1 Stack Overflow Developer Survey (fuente primaria)

Encuesta anual con 50.000–100.000 respondentes profesionales del mundo del software. Disponible desde 2011 con datasets descargables en CSV.

- **URL:** https://survey.stackoverflow.co/
- **Datos extraídos por año (2016–2025):**
  - `% de respondentes que usaron Rust en el último año` (campo "worked with")
  - `% de respondentes que aman/admiran Rust` (campo "loved" hasta 2022, "admired" desde 2023)
  - `% de respondentes que usaron C++` (para comparación)
  - Total de respondentes (para ponderar significancia estadística)
- **Justificación:** es la encuesta más citada del sector, con muestra robusta y metodología consistente (con la salvedad del cambio "loved" → "admired" en 2023, documentado).

### 1.2 TIOBE Programming Community Index (validación cruzada)

Índice mensual que mide popularidad de lenguajes por volumen de búsqueda agregado en buscadores y sitios técnicos.

- **URL:** https://www.tiobe.com/tiobe-index/
- **Datos extraídos:** posición histórica de Rust y rating porcentual del índice, hitos mensuales relevantes (entrada al top 20 en jun 2020, salto al top 13 tras el informe del White House en jul 2024, etc.).
- **Justificación:** sirve para validar que la tendencia de la encuesta de Stack Overflow no es un artefacto de su muestra. Si ambas fuentes coinciden en la dirección del crecimiento, el modelo tiene un sustento más sólido.

### 1.3 Google Trends (interés de búsqueda)

Índice 0–100 normalizado al pico del período, comparativo entre términos de búsqueda.

- **URL:** https://trends.google.com/trends/
- **Términos:** "Rust (programming language)" vs "C++"
- **Período:** 2015-01 a 2026-06 (mundial)
- **Justificación:** mide el interés social por la tecnología, no su uso real. Útil como proxy del componente *q* (boca a boca / imitación) del modelo Bass.

### 1.4 Prensa especializada (contextualización)

- InfoWorld, TechRepublic, developer-tech.com, ZenRows, Yalantis.
- **Justificación:** se usan para identificar eventos exógenos relevantes (shocks regulatorios, anuncios corporativos) que el modelo debe contemplar como cambios en el parámetro *p* (innovación / influencia externa).

---

## 2. Proceso de recolección

### 2.1 Stack Overflow

Para cada año de 2016 a 2025 se accedió al apartado "Technology" del reporte público. Las cifras de "worked with %" y "loved/admired %" se anotaron en planilla. Para los años 2016–2017, donde Rust tenía bajo volumen, se cruzaron con reportes de prensa para validar.

**Herramienta de IA usada:** se le pidió a Claude (Anthropic) buscar y validar las series numéricas que aparecen en múltiples reportes para reducir el riesgo de error de transcripción. Prompts utilizados (ver sección "Prompts de IA" del portafolio).

### 2.2 TIOBE

Como TIOBE no publica el histórico mensual completo en formato descargable, se reconstruyó la serie a partir de los reportes mensuales destacados en TechRepublic e InfoWorld, focalizando en los puntos de cambio significativo de posición.

### 2.3 Google Trends

Descarga manual del CSV desde la plataforma. Esta porción queda como tarea del usuario para asegurar reproducibilidad y mantener los datos actualizados al momento de la entrega.

---

## 3. Estructuración y limpieza (etapa 3)

### 3.1 Decisiones de unificación

- **Eje temporal:** se decidió usar año calendario como eje principal porque la fuente primaria (Stack Overflow) es anual. Los datos mensuales de TIOBE y Google Trends se usan como información complementaria, no como insumo principal de la simulación.
- **Variable principal del modelo:** `rust_pct` (% de devs que trabajaron con Rust según SO). Esta variable se interpreta como N(t)/m donde m es el mercado potencial.

### 3.2 Tratamientos aplicados

| Problema detectado | Tratamiento |
|---|---|
| Cambio metodológico "loved" → "admired" en 2023 | Se conservan ambas etiquetas en la columna de admiración. No afecta la variable principal (`rust_pct`). |
| Caída en 2024 (12.6 vs 13.05 en 2023) | Se mantiene tal cual. Posible explicación: efecto de Python sobre la muestra. Se documenta para discusión en el informe. |
| Cifras de respondentes variables por año (49k–100k) | Se incluye la columna `so_respondents_k` para evaluar significancia. No se aplican pesos. |
| Datos faltantes en TIOBE meses intermedios | Se opta por usar solo los hitos identificados, no interpolar. |

### 3.3 Validación cruzada

Las tres fuentes principales coinciden en la dirección del crecimiento de Rust en el período 2018–2025:

- Stack Overflow: % usuarios sube de 3.2% → 14.6% (×4.6)
- TIOBE: posición sube de #38 → #12 (subida de 26 posiciones)
- Prensa: reporta hitos coincidentes (Linux acepta Rust, Rust Foundation, White House report, CRA EU)

Esta convergencia respalda la elección del modelo Bass como representación adecuada del fenómeno.

---

## 4. Salida final

Los siguientes archivos quedan disponibles para la etapa 4 (formulación del modelo y simulación):

- `dataset_adopcion_rust_vs_cpp.xlsx` — libro Excel con 6 hojas: README, Datos_Anuales, TIOBE_Mensual, Trends_Mensual (template), Para_Simulacion, Fuentes.
- `datos_para_simulacion.csv` — CSV mínimo con las series N(t) y C(t) listo para pandas/NumPy.
- `README_recoleccion_datos.md` — este documento, va al portafolio digital.

---

## 5. Reflexión crítica sobre el uso de IA en esta etapa

**Qué hizo bien:** Claude resultó útil para localizar las cifras dispersas en múltiples reportes anuales y consolidar la serie histórica. También ayudó a identificar el cambio metodológico de Stack Overflow en 2023, algo que un trabajo manual hubiera tardado más en detectar.

**Qué hubo que controlar:** algunas cifras propuestas inicialmente diferían según el reporte. Se cruzaron con al menos dos fuentes independientes antes de aceptarlas como definitivas. Para los años más viejos (2016–2017) la confianza en el dato es menor; esto se asume y se documenta.

**Limitación principal:** la IA puede sugerir datos que parecen razonables pero contienen pequeños errores. La validación contra fuentes primarias (sitios oficiales de Stack Overflow y TIOBE) es indispensable. El criterio profesional del estudiante prevalece.
