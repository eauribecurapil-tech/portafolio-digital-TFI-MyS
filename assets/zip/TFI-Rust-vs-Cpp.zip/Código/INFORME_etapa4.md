# Etapa 4 — Formulación del modelo e implementación de la simulación

**Trabajo Final Integrador — Modelos y Simulación**
**Tema:** Adopción de Rust como reemplazo de C++ en programación de sistemas
**Modelo:** Bass de difusión (variante del SIR)

---

## 1. Selección del modelo

Se eligió el **modelo Bass de difusión**, una variante del SIR adaptada al fenómeno de adopción tecnológica. Los argumentos para la elección son tres:

**1. Coherencia con la teoría de la materia.** El apunte de Clase 1 presenta el SIR como modelo de propagación; el Bass es su contraparte para innovaciones, con tres compartimentos: No-enterados → Adoptantes → Saturados. Las ecuaciones se derivan del mismo principio: la tasa de cambio depende del producto entre influencias internas y externas.

**2. Forma compatible con los datos.** La serie temporal de adopción de Rust dibuja una S característica (mesa plana 2015–2018, despegue 2019–2021, aceleración 2022–2024, posible saturación 2025–2027), exactamente la forma que el Bass produce.

**3. Posibilidad de escenarios contrafácticos.** El modelo separa influencia externa (parámetro *p*) de boca a boca (*q*), lo que permite simular shocks regulatorios manipulando solo *p* y dejar *q* invariante.

### 1.1 Ecuación del modelo

$$\frac{dN(t)}{dt} = \left(p + q\cdot\frac{N(t)}{m}\right)\cdot(m - N(t))$$

Donde:
- $N(t)$: fracción acumulada de adoptantes en el tiempo $t$
- $p$: coeficiente de innovación (influencia externa: regulación, anuncios corporativos)
- $q$: coeficiente de imitación (boca a boca entre desarrolladores)
- $m$: mercado potencial (techo de adopción)

La ecuación tiene **solución analítica**, lo que simplifica el ajuste:

$$N(t) = m \cdot \frac{1 - e^{-(p+q)t}}{1 + \frac{q}{p}e^{-(p+q)t}}$$

Para los escenarios donde *p* varía en el tiempo (shock regulatorio), se usa **integración numérica** con `scipy.integrate.odeint`.

---

## 2. Implementación

Se implementó en **Python 3** con las librerías `numpy`, `scipy`, `pandas` y `matplotlib`. El código completo está en `simulacion_bass.py`.

El script consta de 8 secciones:
1. Carga de datos limpios desde `datos_para_simulacion.csv`.
2. Definición del modelo Bass analítico y ajuste con `scipy.optimize.curve_fit`.
3. Validación train/test (corte en 2022).
4. Modelo numérico para escenarios con parámetros variables en el tiempo.
5. Simulación de 4 escenarios proyectados a 2030.
6. Modelo auxiliar para C++ (decaimiento exponencial).
7. Generación de 6 figuras publicables.
8. Exportación de resultados en CSV y JSON.

---

## 3. Ajuste de parámetros

Se ajustó el modelo contra los datos completos de Stack Overflow Survey (2016–2025) usando mínimos cuadrados no lineales con cotas razonables sobre los parámetros.

### Parámetros ajustados

| Parámetro | Valor | Error estándar | Interpretación |
|---|---|---|---|
| $p$ (innovación) | **0.0445** | ± 0.0137 | Influencia externa moderada-alta |
| $q$ (imitación) | **0.315** | ± 0.250 | Boca a boca activo entre devs |
| $m$ (mercado potencial) | **19.6%** | ± 8.7% | Techo cercano al pico histórico de C++ |

### Métricas del ajuste

- **R² = 0.95** — el modelo explica el 95% de la varianza de los datos. Excelente para un fenómeno con shocks exógenos no modelados.
- **RMSE = 1.03 pp** — el error típico es de 1 punto porcentual sobre valores entre 2% y 14.6%.

La razón $q/p \approx 7$ es alta: indica que el componente social (boca a boca) domina ampliamente sobre la influencia externa. Esto es consistente con la cultura de adopción en programación, donde los desarrolladores se influencian fuertemente entre pares.

---

## 4. Validación out-of-sample

Para confirmar que el modelo no solo *describe* los datos sino que también *predice*, se hizo un corte temporal:

- **Train:** 2016–2022 (7 puntos)
- **Test:** 2023–2025 (3 puntos)

### Resultado de la predicción

| Año | Valor real | Predicción | Error |
|---|---|---|---|
| 2023 | 13.05% | 10.98% | −2.07 pp |
| 2024 | 12.60% | 13.13% | +0.53 pp |
| 2025 | 14.60% | 15.43% | +0.83 pp |

**RMSE en test = 1.32 pp** — la predicción se mantiene en el mismo orden de magnitud que el ajuste, lo que valida la capacidad predictiva del modelo. La subestimación de 2023 es interesante: el modelo (entrenado sin saber del informe del White House de febrero 2024) no anticipa el salto fuerte que se observa en 2023, lo cual *refuerza* la hipótesis del efecto regulatorio.

---

## 5. Escenarios contrafácticos

Se simularon 4 escenarios proyectados hasta 2030, variando **una sola variable por escenario** (criterio del enunciado):

### Escenario 1 — Base
Continuación con los parámetros ajustados, sin shocks adicionales.

### Escenario 2 — Shock regulatorio
A partir de t=8 (año 2024), se duplica el parámetro *p* para representar el efecto combinado del informe del White House sobre lenguajes memory-safe y la entrada en vigor de la Cyber Resilience Act europea en marzo 2026.

### Escenario 3 — Conservador
Se reduce el mercado potencial $m$ a 70% del valor base (≈13.7%), representando un techo más realista si Rust no logra desplazar completamente nichos de C++ embebido y desarrollo de bajo nivel histórico.

### Escenario 4 — SIR con abandono
Variante con tres compartimentos: se incorpora una tasa de abandono $\alpha = 0.05$ (5% anual de usuarios que prueban Rust y vuelven a C++). Permite separar "adoptantes activos" de "adoptantes acumulados".

### Resultados proyectados a 2030

| Escenario | Rust % en 2030 | Diferencia vs. base |
|---|---|---|
| Base | 18.6% | — |
| Shock regulatorio | 18.9% | +0.3 pp |
| Conservador | 13.0% | −5.6 pp |
| SIR con abandono (activos) | ~15% | −3.6 pp |

**Nota interpretativa:** el escenario "shock" da resultado similar al base porque los datos hasta 2025 ya incorporan parte del efecto del informe del White House. Si se hubiera ajustado el modelo solo hasta 2023 (pre-informe), el efecto contrafáctico hubiera sido mayor. Esta sutileza se documenta en la reflexión crítica.

---

## 6. Respuesta a la pregunta de investigación

> *¿Cómo evoluciona la adopción de Rust como reemplazo de C++ en programación de sistemas, y qué factores aceleran o frenan ese proceso?*

### Predicción cuantitativa

Combinando el modelo Bass (Rust) con un decaimiento exponencial ajustado para C++ ($C(t) = 5\% + (29.4\% - 5\%)e^{-0.052t}$), el cruce donde **Rust supera a C++ en uso ocurre en 2028.2** en el escenario base, y en **2028.0** en el escenario con shock regulatorio.

### Factores aceleradores identificados (parámetro *p*)

1. **Regulación memory-safe** (White House 2024, CRA EU 2026): efecto visible en los datos como saltos en 2024 y 2026.
2. **Adopción por grandes corporaciones** (Linux kernel, Microsoft, AWS): refuerza la legitimidad institucional.

### Factores frenadores

1. **Costo de migración**: codebases legacy en C++ no se reescriben de un día para otro.
2. **Curva de aprendizaje**: el sistema de ownership de Rust es difícil para devs C++ experimentados.
3. **Ecosistema embebido**: nichos donde C++ tiene ventajas de toolchain y librerías.

### Velocidad de adopción

El modelo identifica que la **velocidad máxima de adopción** (pico de dN/dt) ocurre alrededor de **2021.5**, con un crecimiento de 2 pp por año. A partir de ese punto, la velocidad disminuye y el sistema se acerca asintóticamente al techo de mercado.

---

## 7. Análisis de sensibilidad

Se exploró cómo varía la trayectoria de adopción ante cambios del ±50% en *p* y *q*. La conclusión es que **el modelo es más sensible a *q* que a *p***: duplicar el boca a boca genera trayectorias mucho más empinadas que duplicar la influencia externa.

Esto tiene una lectura ingenieril clara: para acelerar la adopción de Rust en la industria, **invertir en comunidades de desarrolladores y casos de éxito visibles tiene más impacto que campañas regulatorias o anuncios corporativos**.

---

## 8. Limitaciones del modelo

El TFI exige reflexión crítica sobre las limitaciones, y este modelo tiene varias:

1. **Mercado potencial fijo**: el modelo asume *m* constante. En realidad, el mercado de programación crece (más desarrolladores cada año) y cambian los nichos.
2. **Sin competencia explícita**: Rust no compite solo con C++. Zig, Go y otros lenguajes pueden ocupar parte del nicho. El modelo no los contempla.
3. **No captura no-monotonicidad**: la pequeña caída de 2024 (13.05% → 12.6%) no la explica el Bass, que es siempre creciente.
4. **Stack Overflow Survey tiene sesgo de muestra**: representa a la comunidad SO, no a "todos los desarrolladores del mundo".
5. **Linealidad del shock regulatorio**: duplicar *p* es una decisión arbitraria. Un análisis más fino podría usar una función de tiempo más realista.

---

## 9. Uso de IA en esta etapa

**Qué hizo Claude (Anthropic):** asistió en estructurar el script de simulación, sugirió la forma analítica del Bass, ayudó a debuggear el ajuste cuando la convergencia inicial fallaba (proponiendo mejores estimaciones iniciales y cotas), y propuso el modelo auxiliar para C++.

**Qué se validó manualmente:** las ecuaciones contra el apunte de Clase 1 y bibliografía clásica de difusión (Bass 1969), los resultados del ajuste contra los datos reales del CSV, y el código contra ejecución reproducible (siempre da el mismo R² y los mismos puntos de cruce).

**Limitación detectada:** el modelo cuando se ajusta con pocos datos (solo train, 7 puntos) lleva el mercado potencial *m* al límite superior de las cotas (100%). Esto refleja que el inflection point no está bien identificado con datos tempranos. Es un fenómeno conocido del Bass y se documenta como tal.

---

## 10. Salidas de esta etapa

- `simulacion_bass.py` — código completo, reproducible.
- `figuras/` — 6 PNG de alta resolución listos para el documento y la web.
- `resultados/proyecciones_2016_2030.csv` — serie temporal completa de los 4 escenarios + C++.
- `resultados/resumen_simulacion.json` — métricas y parámetros para integrar en el portafolio.

Listos para alimentar la etapa 5 (documentación del portafolio: documento de Google → PDF + web interactiva tipo diapositivas).
